![Tec de Monterrey](images/logotecmty.png)

CS Tool - Mastering Analytics (TC1002S)
It is a basic level workshop in which the student will explore in a practical way key aspects of engineering and basic tools of the profession. It does not require prior knowledge. As a result of the learning, the student will know fundamental computational tools such as Unix commands, Terminal management, and version management. This practical workshop will follow one of the following two themes: data visualization, or pattern recognition.
